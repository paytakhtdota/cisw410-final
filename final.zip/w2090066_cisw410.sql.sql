-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2025 at 07:49 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `w2090066_cisw410`
--
CREATE DATABASE IF NOT EXISTS `w2090066_cisw410` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `w2090066_cisw410`;

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `location_id` smallint(6) NOT NULL,
  `state` varchar(16) NOT NULL,
  `city` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `unit` varchar(8) DEFAULT NULL,
  `zip_code` varchar(10) NOT NULL,
  `add_type` enum('event','user','admin','') NOT NULL DEFAULT 'event'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`location_id`, `state`, `city`, `street`, `unit`, `zip_code`, `add_type`) VALUES
(1, 'California', 'West Sacramento', '900 Simon Terrace', '63', '95605', 'event'),
(2, 'California', 'West Sacramento', '900 Simon Terrace', '63', '95605', 'event'),
(3, 'California', 'Sacramento', '1110 2nd St', '', '95814', 'event'),
(4, 'California', 'Sacramento', '1110 2nd St', '', '95814', 'event'),
(5, 'California', 'Sacramento', '1110 2nd St', '', '95814', 'event'),
(6, 'California', 'Sacramento', '1110 2nd St', '', '95814', 'event'),
(7, 'California', 'Sacramento', '1110 2nd St', '', '95814', 'event');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id_event` smallint(6) NOT NULL COMMENT 'events id',
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time DEFAULT NULL,
  `img` varchar(511) DEFAULT NULL,
  `location_id` smallint(6) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id_event`, `name`, `date`, `start_time`, `end_time`, `img`, `location_id`, `description`) VALUES
(1, 'Night 1: Symphonic Orchestra \"The Beginning\"', '2025-05-08', '20:00:00', NULL, 'public/upload/67d7a9c3db350AdobeStock_71758726.jpg', 1, ''),
(2, 'Night 2: Orchestral Music \"Symphony and Orchestra\"', '2025-05-09', '20:00:00', NULL, 'public/upload/67d7ac1333326night2.jpg', 2, ''),
(3, 'Night 3: Chamber Music \"Personal Moments\"', '2025-05-10', '20:00:00', NULL, 'public/upload/67d7aff206a1dnight3.jpg', 3, ''),
(4, 'Night 4: Opera Music \"Magic and Enchantment\"', '2025-05-11', '08:00:00', NULL, 'public/upload/67d7b0d767902night4.jpg', 4, ''),
(5, 'Night 5: Piano Music \"Piano Magic\"', '2025-05-12', '20:00:00', NULL, 'public/upload/67d7b188f045anight5.jpg', 5, ''),
(6, 'Night 6: Medieval Music \"Shadows and Light\"', '2025-05-13', '20:00:00', NULL, 'public/upload/67d7b2b723c46night6.jpg', 6, ''),
(7, 'Night 7: Contemporary Music \"New Art\"', '2025-05-14', '20:00:00', NULL, 'public/upload/67d7b34e68629night7.jpg', 7, '\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `seats`
--

CREATE TABLE `seats` (
  `id_seat` smallint(6) NOT NULL,
  `seat_type` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `seats_events_prices`
--

CREATE TABLE `seats_events_prices` (
  `seat_type` tinyint(2) NOT NULL,
  `id_event` smallint(6) NOT NULL,
  `price` decimal(7,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `id_ticket` mediumint(9) NOT NULL COMMENT 'id primary key',
  `guest_fname` int(11) DEFAULT NULL,
  `guest_lname` int(11) DEFAULT NULL,
  `purchase_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `id_seat` smallint(6) NOT NULL,
  `id_event` smallint(6) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL COMMENT 'user id',
  `fname` varchar(50) NOT NULL COMMENT 'first name',
  `lname` varchar(50) NOT NULL COMMENT 'last name',
  `prefix` enum('Mr.','Mrs.','Miss.','Ms.') DEFAULT NULL COMMENT 'prefix / title',
  `email` varchar(100) NOT NULL COMMENT 'email',
  `password` varchar(255) NOT NULL COMMENT 'password - users',
  `phone` varchar(16) DEFAULT NULL COMMENT 'phone number',
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'update / create time',
  `privilege_level` tinyint(4) NOT NULL DEFAULT 0,
  `img_path` varchar(1024) NOT NULL DEFAULT 'public/upload/notset2.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `fname`, `lname`, `prefix`, `email`, `password`, `phone`, `create_at`, `privilege_level`, `img_path`) VALUES
(5, 'Mohammad', 'Ansari', NULL, 'admin@admin.com', '$2y$10$Zr6RIkTynk9.4IFkpfb43Oi15MUPurJDacaTl3pFEfoTQnBRI9K1K', '2076151337', '2025-03-02 21:41:40', 5, 'public/upload/notset2.png'),
(25, 'New admin', 'New', NULL, 'new@admin.com', '$2y$10$ap7STD5SBqEnynatPhVlkemfkcXmSsW2lxhcBNKMoEq.QCq1VkpAq', '2076151337', '2025-03-06 21:54:47', 5, 'public/upload/notset2.png'),
(28, 'Mohammad', 'Ansari', NULL, 'paytakhtdota12312312@gmail.com', '$2y$10$TT2zykC/r76pLbzDj50KaObl1cHLB.zG.Xi6azBoCJ5nR/N2hXdFa', '2076151337', '2025-03-07 07:26:36', 4, 'public/upload/notset2.png'),
(29, 'Mohammad', 'Ansari', NULL, 'paytakht234234234dota@gmail.com', '$2y$10$Jn2KFd4.Qrv9UpNJmwv4We9CEqIPSPib/YUBKfnx/lRVzuETzXrMu', '2076151337', '2025-03-07 07:29:43', 4, 'public/upload/notset2.png'),
(30, 'Mohammad', 'Ansari', NULL, 'pay5656ota@gmail.com', '$2y$10$28AdYXOqt.1UiqRqKsYHYu343rm5gGWPw.3i1GdePwk4T2HrqMiQ6', '2076151337', '2025-03-07 07:51:01', 5, 'public/upload/notset2.png'),
(31, 'Mohammad', 'Ansari2', NULL, 'paytsadfasdfakhtdota@gmail.com', '$2y$10$oOzrfO79/E1kdgLYe62T.ukCcMBr1SzfiUiO/2CyNVdJNJzpiw4t.', '2076151337', '2025-03-07 08:05:23', 0, 'public/upload/notset2.png'),
(32, 'Mohammad', 'Ansari', NULL, 'takhtasddota@gmail.com', '$2y$10$1JlUqBY7qAhhyNSnwsnjEu4MuHIwqW67.7ekIKmCedOvd3NxAO0YW', '2076151337', '2025-03-07 08:10:15', 0, 'public/upload/notset2.png'),
(35, 'Test', 'Test', NULL, 'user@user.com', '$2y$10$hglBCThy2NaE9.dJyjU2m.cp55XX0LvOvTvgmuyw4nGLGZJ6ppl3q', '1', '2025-03-09 19:32:39', 0, 'public/upload/notset2.png'),
(36, 'User', 'Test', NULL, 'test@test', '$2y$10$gdJV0Wj.kLde8Mgm3IwLrOtylIEyiDwkW8bhtrH.FclVq8bH2HHV6', '207222123123', '2025-03-15 20:33:01', 0, 'public/upload/67d7c045ef58bpngtree-cartoon-color-simple-male-avatar-png-image_5230557.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id_event`),
  ADD KEY `location_id` (`location_id`);

--
-- Indexes for table `seats`
--
ALTER TABLE `seats`
  ADD PRIMARY KEY (`id_seat`) USING BTREE,
  ADD UNIQUE KEY `type` (`seat_type`);

--
-- Indexes for table `seats_events_prices`
--
ALTER TABLE `seats_events_prices`
  ADD PRIMARY KEY (`seat_type`,`id_event`),
  ADD KEY `id_event` (`id_event`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id_ticket`),
  ADD UNIQUE KEY `ticket_seat` (`id_event`,`id_seat`),
  ADD KEY `id_seat` (`id_seat`),
  ADD KEY `tickets_ibfk_1` (`id_user`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `location_id` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id_event` smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'events id', AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id_ticket` mediumint(9) NOT NULL AUTO_INCREMENT COMMENT 'id primary key';

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT COMMENT 'user id', AUTO_INCREMENT=37;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `address` (`location_id`);

--
-- Constraints for table `seats_events_prices`
--
ALTER TABLE `seats_events_prices`
  ADD CONSTRAINT `seats_events_prices_ibfk_1` FOREIGN KEY (`seat_type`) REFERENCES `seats` (`seat_type`),
  ADD CONSTRAINT `seats_events_prices_ibfk_2` FOREIGN KEY (`id_event`) REFERENCES `events` (`id_event`);

--
-- Constraints for table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE CASCADE,
  ADD CONSTRAINT `tickets_ibfk_2` FOREIGN KEY (`id_seat`) REFERENCES `seats` (`id_seat`) ON UPDATE CASCADE,
  ADD CONSTRAINT `tickets_ibfk_3` FOREIGN KEY (`id_event`) REFERENCES `events` (`id_event`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
