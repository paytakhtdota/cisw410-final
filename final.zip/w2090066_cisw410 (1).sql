-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2025 at 06:30 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `w2090066_cisw410`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `location_id` smallint(6) NOT NULL,
  `state` varchar(16) NOT NULL,
  `city` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `unit` varchar(8) DEFAULT NULL,
  `zip_code` varchar(10) NOT NULL,
  `add_type` enum('event','user','admin','') NOT NULL DEFAULT 'event'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id_event` smallint(6) NOT NULL COMMENT 'events id',
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `location_id` smallint(6) NOT NULL,
  `description` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `seats`
--

CREATE TABLE `seats` (
  `id_seat` smallint(6) NOT NULL,
  `seat_type` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `seats_events_prices`
--

CREATE TABLE `seats_events_prices` (
  `seat_type` tinyint(2) NOT NULL,
  `id_event` smallint(6) NOT NULL,
  `price` decimal(7,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `id_ticket` mediumint(9) NOT NULL COMMENT 'id primary key',
  `guest_fname` int(11) DEFAULT NULL,
  `guest_lname` int(11) DEFAULT NULL,
  `purchase_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `id_seat` smallint(6) NOT NULL,
  `id_event` smallint(6) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL COMMENT 'user id',
  `fname` varchar(50) NOT NULL COMMENT 'first name',
  `lname` varchar(50) NOT NULL COMMENT 'last name',
  `prefix` enum('Mr.','Mrs.','Miss.','Ms.') DEFAULT NULL COMMENT 'prefix / title',
  `email` varchar(100) NOT NULL COMMENT 'email',
  `password` varchar(255) NOT NULL COMMENT 'password - users',
  `phone` varchar(16) DEFAULT NULL COMMENT 'phone number',
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'update / create time',
  `privilege_level` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `fname`, `lname`, `prefix`, `email`, `password`, `phone`, `create_at`, `privilege_level`) VALUES
(5, 'Mohammad', 'Ansari', NULL, 'admin@admin.com', '$2y$10$Zr6RIkTynk9.4IFkpfb43Oi15MUPurJDacaTl3pFEfoTQnBRI9K1K', '2076151337', '2025-03-02 21:41:40', 5),
(25, 'New admin', 'New', NULL, 'new@admin.com', '$2y$10$ap7STD5SBqEnynatPhVlkemfkcXmSsW2lxhcBNKMoEq.QCq1VkpAq', '2076151337', '2025-03-06 21:54:47', 5),
(28, 'Mohammad', 'Ansari', NULL, 'paytakhtdota12312312@gmail.com', '$2y$10$TT2zykC/r76pLbzDj50KaObl1cHLB.zG.Xi6azBoCJ5nR/N2hXdFa', '2076151337', '2025-03-07 07:26:36', 4),
(29, 'Mohammad', 'Ansari', NULL, 'paytakht234234234dota@gmail.com', '$2y$10$Jn2KFd4.Qrv9UpNJmwv4We9CEqIPSPib/YUBKfnx/lRVzuETzXrMu', '2076151337', '2025-03-07 07:29:43', 4),
(30, 'Mohammad', 'Ansari', NULL, 'pay5656ota@gmail.com', '$2y$10$28AdYXOqt.1UiqRqKsYHYu343rm5gGWPw.3i1GdePwk4T2HrqMiQ6', '2076151337', '2025-03-07 07:51:01', 5),
(31, 'Mohammad', 'Ansari', NULL, 'paytsadfasdfakhtdota@gmail.com', '$2y$10$oOzrfO79/E1kdgLYe62T.ukCcMBr1SzfiUiO/2CyNVdJNJzpiw4t.', '2076151337', '2025-03-07 08:05:23', 0),
(32, 'Mohammad', 'Ansari', NULL, 'takhtasddota@gmail.com', '$2y$10$1JlUqBY7qAhhyNSnwsnjEu4MuHIwqW67.7ekIKmCedOvd3NxAO0YW', '2076151337', '2025-03-07 08:10:15', 0),
(35, 'Test', 'Test', NULL, 'user@user.com', '$2y$10$hglBCThy2NaE9.dJyjU2m.cp55XX0LvOvTvgmuyw4nGLGZJ6ppl3q', '1', '2025-03-09 19:32:39', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id_event`),
  ADD KEY `location_id` (`location_id`);

--
-- Indexes for table `seats`
--
ALTER TABLE `seats`
  ADD PRIMARY KEY (`id_seat`) USING BTREE,
  ADD UNIQUE KEY `type` (`seat_type`);

--
-- Indexes for table `seats_events_prices`
--
ALTER TABLE `seats_events_prices`
  ADD PRIMARY KEY (`seat_type`,`id_event`),
  ADD KEY `id_event` (`id_event`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id_ticket`),
  ADD UNIQUE KEY `ticket_seat` (`id_event`,`id_seat`),
  ADD KEY `id_seat` (`id_seat`),
  ADD KEY `tickets_ibfk_1` (`id_user`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `location_id` smallint(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id_event` smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'events id';

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id_ticket` mediumint(9) NOT NULL AUTO_INCREMENT COMMENT 'id primary key';

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT COMMENT 'user id', AUTO_INCREMENT=36;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `address` (`location_id`);

--
-- Constraints for table `seats_events_prices`
--
ALTER TABLE `seats_events_prices`
  ADD CONSTRAINT `seats_events_prices_ibfk_1` FOREIGN KEY (`seat_type`) REFERENCES `seats` (`seat_type`),
  ADD CONSTRAINT `seats_events_prices_ibfk_2` FOREIGN KEY (`id_event`) REFERENCES `events` (`id_event`);

--
-- Constraints for table `tickets`
--
ALTER TABLE `tickets`
  ADD CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE CASCADE,
  ADD CONSTRAINT `tickets_ibfk_2` FOREIGN KEY (`id_seat`) REFERENCES `seats` (`id_seat`) ON UPDATE CASCADE,
  ADD CONSTRAINT `tickets_ibfk_3` FOREIGN KEY (`id_event`) REFERENCES `events` (`id_event`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
