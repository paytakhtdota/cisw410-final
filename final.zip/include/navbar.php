<nav>
    <div class="left-side">
        <a href="#"><img src="public/images/logo2.png" alt="logo"></a>
        <a href="index.php">Home</a>
        <a href="#">Reservation</a>
        <a href="contact.php">Contact</a>
        <a href="about.php">About</a>
    </div>
    <div class="right-side">
<button class="button-61">Sign Up</button>
<button class="button-61">Log In</button>
    </div>
</nav>